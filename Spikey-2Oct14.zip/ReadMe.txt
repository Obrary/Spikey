Product: Spikey, October 2014

Designer: Chris Wundram

Support:  http://forums.obrary.com/category/designs/spikey

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design

Description:
Spikey is a stellated truncated dodecahedron made from acrylic and cut on a laser cutter. It is also the logo for Mathematica.